package com.example.mavuno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavunoApplicationTests {

	@Test
	void contextLoads() {
	}

}
