package com.example.mavuno.model;

import lombok.Data;

@Data
public class RequestHeader {

    private String messageID;
    private String featureCode;
    private String featureName;
    private String serviceCode;
    private String serviceSubCategory;
    private String minorServiceVersion;
    private String channelCode;
    private String channelName;
    private String routeCode;
    private String timeStamp;
    private String serviceMode;
    private String subscribeEvents;
    private String callBackURL;

}
