package com.example.mavuno.model;

import lombok.Data;

@Data
public class TransactionInfo {

    private String companyCode;
    private String transactionType;
    private String creditAccountNumber;
    private String credintMobileNumber;
    private String transactionAmount;
    private String transactionReference;
    private String currencyCode;
    private String amountCurrency;
    private String dateTime;
    private String dateString;
}
