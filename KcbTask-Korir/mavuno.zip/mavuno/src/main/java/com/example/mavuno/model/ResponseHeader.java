package com.example.mavuno.model;

import lombok.Data;

@Data
public class ResponseHeader {

    private String messageID;
    private String conversationID;
    private String targetSystemID;
    private String routeCode;
    private String statusCode;
    private String statusDescription;
    private String statusMessage;
}
