package com.example.mavuno.model;

import lombok.Data;

@Data
public class ResponseTransactionInfo {
    private String transactionId;
    private String falconBalance;
}
