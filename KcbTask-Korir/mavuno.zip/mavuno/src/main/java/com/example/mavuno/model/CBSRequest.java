package com.example.mavuno.model;

import lombok.Data;

@Data
public class CBSRequest {

    private RequestHeader requestHeader;
    private RequestPayload requestPayload;
}
