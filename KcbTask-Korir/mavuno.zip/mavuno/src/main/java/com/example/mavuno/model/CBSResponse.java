package com.example.mavuno.model;

import lombok.Data;

@Data
public class CBSResponse {
    private ResponseHeader header;
    private ResponsePayload responsePayload;
}
