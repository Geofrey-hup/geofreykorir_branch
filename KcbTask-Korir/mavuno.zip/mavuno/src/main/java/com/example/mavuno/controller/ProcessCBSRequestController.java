package com.example.mavuno.controller;

import com.example.mavuno.model.*;
import com.example.mavuno.service.B2CService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/cbs")
@Slf4j
public class ProcessCBSRequestController {

    @Autowired
    B2CService b2CService;

    @PostMapping
    public ResponseEntity process(@RequestBody CBSRequest cbsRequest){
        if(log.isDebugEnabled()){
            log.debug("Received a request {}", cbsRequest);
        }

        // LOG request above in our database
        // TODO send mpesa request


        String response = b2CService.sendRequest(cbsRequest);
        if(response.equals("SUCCESS")){
                return  new ResponseEntity(getSuccessResponse(), HttpStatus.OK);
        }else {
            //return with correct desc
            return  new ResponseEntity("", HttpStatus.OK);
        }
    }

    private CBSResponse getSuccessResponse() {
        CBSResponse response = new CBSResponse();
        ResponseHeader responseHeader = new ResponseHeader();
        responseHeader.setMessageID("12345666");

        ResponseTransactionInfo responseTransactionInfo = new ResponseTransactionInfo();
        responseTransactionInfo.setTransactionId("FT20114XHFQF");

        ResponsePayload responsePayload = new ResponsePayload();
        responsePayload.setTransactionInfo(responseTransactionInfo);

        response.setHeader(responseHeader);
        response.setResponsePayload(responsePayload);
        return  response;
    }
}
