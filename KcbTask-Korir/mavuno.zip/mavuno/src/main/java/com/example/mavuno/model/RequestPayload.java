package com.example.mavuno.model;

import lombok.Data;

@Data
public class RequestPayload {

    private TransactionInfo transactionInfo;
}
