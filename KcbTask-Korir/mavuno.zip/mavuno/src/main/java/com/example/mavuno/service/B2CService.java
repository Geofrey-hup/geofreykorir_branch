package com.example.mavuno.service;

import com.example.mavuno.model.CBSRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class B2CService {

    public String sendRequest(CBSRequest cbsRequest) {
        try{
            log.info("Sending B2C request for {}");

            //if successful
            return "SUCCESS";
        }catch (Exception e){
            log.error("Error occurred while sendRequest: ", e);
            return e.getMessage() != null ? e.getMessage() : "Error occurred";
        }
    }
}
